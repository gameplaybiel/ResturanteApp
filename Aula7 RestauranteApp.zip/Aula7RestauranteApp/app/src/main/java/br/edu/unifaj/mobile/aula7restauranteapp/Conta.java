package br.edu.unifaj.mobile.aula7restauranteapp;

import java.util.ArrayList;

public class Conta {

    public static class Produto{
        String name;
        int quant;
        double value;

        public String toString(){
            return name + " " + quant + " " + value;
        }
    }

    String client;
    int table;
    double value;
    ArrayList<Produto> produtos = new ArrayList<>();
}