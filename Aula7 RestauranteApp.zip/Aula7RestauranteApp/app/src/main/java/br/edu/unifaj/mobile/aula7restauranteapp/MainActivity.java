package br.edu.unifaj.mobile.aula7restauranteapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class MainActivity extends AppCompatActivity {
    
    String json = "{\n" +
            "  \"client\": \"Joao\",\n" +
            "  \"table\": 10,\n" +
            "  \"value\": 370.0,\n" +
            "  \"produtos\": [\n" +
            "    {\"name\":  \"Batata\", \"quant\": 1, \"value\":  70.0},\n" +
            "    {\"name\":  \"Iscas de frango\", \"quant\": 1, \"value\":  100.0},\n" +
            "    {\"name\":  \"Finho\", \"quant\": 1, \"value\":  200.0}\n" +
            "  ]\n" +
            "}";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        try {
            Conta conta = parserJson();
            apresentarConta(conta);
        } catch(Exception ex) {
            ex.printStackTrace(); // Grava no LOG o problema
            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public Conta parserJson() throws Exception {
        Conta conta = new Conta();

        JSONObject object = (JSONObject) new JSONTokener(json).nextValue();
        conta.client = object.getString("client");
        conta.table = object.getInt("table");
        conta.value = object.getDouble("value");
        JSONArray produtos = object.getJSONArray("produtos");
        for (int i = 0; i < produtos.length(); i++) {
            Conta.Produto produto = new Conta.Produto();
            JSONObject productObj = produtos.getJSONObject(i);
            produto.name = productObj.getString("name");
            produto.quant = productObj.getInt("quant");
            produto.value = productObj.getDouble("value");
            conta.produtos.add(produto);
        }
        return conta;
    }

    public void apresentarConta(Conta conta){
        EditText clientET = findViewById(R.id.main_client_editText);
        EditText tableET = findViewById(R.id.main_table_editText);
        EditText valueET = findViewById(R.id.main_value_editText);
        ListView productsLV = findViewById(R.id.main_product_ListView);

        //Atribuir os valores
        clientET.setText(conta.client);
        tableET.setText(Integer.toString(conta.table));
        valueET.setText(Double.toString(conta.value));
        ArrayAdapter adapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_checked, conta.produtos);
        productsLV.setAdapter(adapter);
    }
}